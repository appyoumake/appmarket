/*
 * MLAB REST API javascript library for the MLAB Market Application
 *
 * Developed by Snapper Net Solutions
 *
 * Copyright (C) 2015 Forsvarets Høgskole
 *
 */

(function( global, factory ) 
{
	if ( typeof module === "object" && typeof module.exports === "object" ) 
	{
		module.exports = global.document ?
			factory( global, true ) :
			function( w ) {
				if ( !w.document ) 
				{
					throw new Error( "MLAB REST API window.document error" );
				}
				return factory( w );
			};
	}
	else 
	{
		factory( global );
	}

// Pass this if window is not defined yet
}(typeof window !== "undefined" ? window : this, function( window, noGlobal )
{
	// @private
	var _host = '';

	var MAX_SCREENSHOTS = 5;

	//
	//

	function validateEmail(email) 
	{ 
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}

	/*
	 * The MLAB class
	 *
	 * This will be automatically instanciated as $MLAB / window.$MLAB
	 *
	 */

	var MLAB = function() {
		var self = this;

		// Set up event listener for input fields
		$(document).on('blur', 'form[data-validate=yes] input', function(e)
		{
			self.validateField($(this));
		});

		// Set up a generic event listener for mouse clicks on elements marked with data-trigger="click"
		$(document).on('click', '*[data-trigger]', function(e)
		{
			var action = $(this).data('action');
			var url = $(this).data('url');
			if (url)
				document.location = url;
			else if (action)
			{
				var fn = $MLAB[action];
				if (typeof fn === 'function')
					fn();
			}
		});

		// Set up default event listener to input fields marked as autocomplete fields
		$(document).off('input[data-mode=autocomplete]');
		$(document).on('keydown', 'input[data-mode=autocomplete]', function(e)
		{
			clearTimeout(self.timer);
			self.timer = null;
		});

		$(document).on('keyup', 'input[data-mode=autocomplete]', function(e)
		{
			clearTimeout(self.timer)
			self.timer = setTimeout(function(){ self.search() }, 700);
		});
	};

	// @public
	MLAB.fn = MLAB.prototype = {
		version : '1.0'
	}

	/*
	 * showTooltip()
	 *
	 * Helper function to highlight required field or field that doesn't validate
	 *
	 * @param: el 			A DOM element INPUT, SELECT, TEXTAREA
	 @ @param: tooltip 		string to display in the tooltip
	 */

	MLAB.fn.showTooltip = function(el, tooltip)
	{
		var self = this;

		el.css({ borderColor: '#fc002a' }).attr('title', tooltip);
		el.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
		$('[data-toggle="tooltip"]').tooltip('show');
		return;
	}

	/*
	 * Sign up and create a user. This method will call /signup on the server
	 * 
	 * @param: form 		A DOM element FORM
	 *
	 */

	MLAB.fn.signup = function(form) {
		var self = this;

		// Get details from form
		var email = $('input[name=email]');
		var realname = $('input[name=real_name]').val();
		var pwd = $('input[name=password]');
		var password = pwd.val();
		var passwort = $('input[name=password2]').val();

		$('#form-feedback').html('');

		// 1. Clear tooltip properties
		$('[data-toggle="tooltip"]').tooltip('destroy');
		email.removeAttr('title');
		email.removeAttr('data-placement');
		email.removeAttr('data-toggle');
		email.css({ borderColor: '#eee' });

		pwd.removeAttr('title');
		pwd.removeAttr('data-placement');
		pwd.removeAttr('data-toggle');
		pwd.css({ borderColor: '#eee' });


		// 2. Validate email (that it's a properly formed email address)
		if (!validateEmail(email.val()))
		{
			email.css({ borderColor: '#fc002a' }).attr('title', "This doesn't appear to be a valid email address");
			email.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
			return;
		}


		// 3. Validate passwords match and consists of at least one upper case, one lower case, one number and one special character
		if (password !== passwort || password.length === 0)
		{
			if (password.length === 0)
			{
				pwd.css({ borderColor: '#fc002a' }).attr('title', "The password can't be empty.");
			}
			else
			{
				pwd.css({ borderColor: '#fc002a' }).attr('title', "The passwords doesn't match.");
			}

			pwd.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
			return;
		}
		else if (password.length < 5)
		{
			pwd.css({ borderColor: '#fc002a' }).attr('title', "The password is too short. Minimum 5 characters.");			
			pwd.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
			return;
		}


		// 4. Submit to server for registration
		var data = { email:email.val(), realname:realname, password:password };

		$.ajax(
		{
			url : '/signup',
			type : 'post',
			cache : false,
			data : JSON.stringify(data),
			contentType : 'application/json',

			success : function(response)
			{
				if (response.success === false)
				{
					$('#form-feedback').html('<div class="alert alert-danger">Username already registered</div>');
				}
				else
				{
					$('#form-feedback').html('<div class="alert alert-success">User created. Now you can <a href="/signin">Sign in</a></div>');
				}
			},

			error : function(error)
			{
				console.log("ERROR", error.statusText);
			}
		})
	}

	/*
	 * Create a user from the User management screen. This will call the method /createUser on the server
	 *
	 * @param: form 		A DOM element FORM
	 *
	 */

	MLAB.fn.createUser = function(form) {
		var self = this;

		// Get details from form
		var email = $('input[name=email]');
		var realname = $('input[name=real_name]').val();
		var pwd = $('input[name=pwd1]');
		var password = pwd.val();
		var passwort = $('input[name=pwd2]').val();
		var token = $('input[name=token]').val();
		var role = $('select[name=role]').val();
		var location = $('input[name=location]').val();
		var tags = $('input[name=tags]').val();

		$('#form-feedback').html('');


		// 1. Clear tooltip properties
		$('[data-toggle="tooltip"]').tooltip('destroy');
		email.removeAttr('title');
		email.removeAttr('data-placement');
		email.removeAttr('data-toggle');
		email.css({ borderColor: '#eee' });

		pwd.removeAttr('title');
		pwd.removeAttr('data-placement');
		pwd.removeAttr('data-toggle');
		pwd.css({ borderColor: '#eee' });


		// 2. Validate email (that it's a properly formed email address)
		if (!validateEmail(email.val()))
		{
			email.css({ borderColor: '#fc002a' }).attr('title', "This doesn't appear to be a valid email address");
			email.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
			return;
		}


		// 3. Validate passwords match and consists of at least one upper case, one lower case, one number and one special character
		if (password !== passwort || password.length === 0)
		{
			if (password.length === 0)
			{
				pwd.css({ borderColor: '#fc002a' }).attr('title', "The password can't be empty.");
			}
			else
			{
				pwd.css({ borderColor: '#fc002a' }).attr('title', "The passwords doesn't match.");
			}

			pwd.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
			return;
		}
		else if (password.length < 5)
		{
			pwd.css({ borderColor: '#fc002a' }).attr('title', "The password is too short. Minimum 5 characters.");			
			pwd.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
			return;
		}

		var data = { token:token, user_details:{ email:email.val(), password:password, realname:realname, role:role, location:location, tags:tags }};

		$.ajax(
		{
			url : '/createUser',
			type : 'post',
			data : JSON.stringify(data),
			contentType : 'application/json',

			success : function(response)
			{
				if (response.success === false)
				{
					$('#form-feedback').html('<div class="alert alert-danger">Username already exists</div>');
				}
				else
				{
					$('#form-feedback').html('<div class="alert alert-success">User created</div>');
					form.reset();
				}
			},

			error : function(error)
			{
				console.log("ERROR", error.statusText);
			}
		});
	}

	/*
	 * Validate a field and mark it if empty or invalid (email not valid fi.)
	 *
	 * @param: field 		A DOM element INPUT field
	 * 
	 */

	MLAB.fn.validateField = function(field)
	{
		var self = this;

		var name = field.attr('name');
		var value = field.val();

		// Remove red border and tooltip info
		$('[data-toggle="tooltip"]').tooltip('destroy');
		field.removeAttr('title');
		field.removeAttr('data-placement');
		field.removeAttr('data-toggle');
		field.css({ borderColor: '#eee' });

		if (name === 'email' && !validateEmail(value))
		{
			field.css({ borderColor: '#fc002a' }).attr('title', "This doesn't appear to be a valid email address");
			field.attr('data-placement', 'right').attr('data-toggle', 'tooltip');
			$('[data-toggle="tooltip"]').tooltip('show');
		}
	}

	/*
	 * getNewUsers()
	 *
	 * This method will call /getNewUsers on the server and present a list of all new users (state=99).
	 * Administrators can then enable or disable individual users.
	 *
	 * @param: el 			A DOM element BUTTON. Used only to find the user's token in the DOM
	 *
	 */

	MLAB.fn.getNewUsers = function(el) {
		var self = this;
		var token = $(el).closest('[data-token]')
		console.log("GETNEWUSERS", token.data('token'));
		var data = { token:token.data('token') };
		$.ajax({
			url : '/getNewUsers',
			type : 'get',
			cache : false,
			data : data,

			success : function(response)
			{
				var html = $('<ul data-token="' + token.data('token') + '"></ul>');
				$.each(response.users, function(n, user)
				{
					html.append('<li data-id="' + user.id + '"><i class="fa fa-user"></i><div class="name">' + user.real_name + '<span>' + user.email + '</span></div><div class="pull-right">setUserState(): <button class="btn btn-success" onclick="$MLAB.setUserState(this, 1)">1</button><button class="btn btn-warning pull-right" onclick="$MLAB.setUserState(this, 0)">0</button></div></li>');
				});

				$('#content').html(html);
			},

			error : function(error)
			{
				console.log("ERROR", error.message);
			}
		});
	}

	/*
	 * setUserState()
	 *
	 * This method will call /setUserState on the server and set the state according to what the user wanted.
	 *
	 * @param: el 			A DOM element BUTTON. Used only to find the user's token in the DOM
	 * @param: state 		Integer - 0=disabled, 1=enabled
	 *
	 */

	MLAB.fn.setUserState = function(el, state) {
		var self = this;
		var token = $(el).closest('[data-token]');
		var row = $(el).closest('li');
		var uid = row.data('id');
		console.log("SETUSERSTATE", uid, token.data('token'), state);
		var data = { token:token.data('token'), uid:uid, state:state };

		$.ajax({
			url : '/setUserState',
			type : 'put',
			cache : false,
			data : JSON.stringify(data),
			contentType : 'application/json',

			success : function(response)
			{
				row.slideUp(function(){ $(this).remove() });
			},

			error : function(error)
			{
				console.log("ERROR", error.message);
			}
		});
	}

	/*
	 * setTaggedUsersState()
	 *
	 * This method calls /setTaggedUsersState on the server and will set the state of users matching the tag to enabled or disabled.
	 *
	 * @param: el 			A DOM element BUTTON. Used only to find the user's token in the DOM
	 * @result: json { success:true/false, users:[list of affected user objects] }
	 *
	 */

	MLAB.fn.setTaggedUsersState = function(el) {
		var self = this;
		var form = $(el).closest('form');
		var token = form.data('token');
		var tag = form.data('tags');
		var state = $('select[name=state]', form).val();

		if (state === '' || tag === '' || !token)
			return;

		var data = { token:token, tag:tag, state:state };

		$.ajax({
			url : '/setTaggedUsersState',
			type : 'put',
			cache : false,
			data : JSON.stringify(data),
			contentType : 'application/json',

			success : function(response)
			{
				$(response.users).each(function(n, user)
				{
					var marker = $('li[data-id=' + user.id + '] .big');
					marker.html(user.state);
				})
				//row.slideUp(function(){ $(this).remove() });
			},

			error : function(error)
			{
				console.log("ERROR", error.message);
			}
		});
	}

	/*
	 * prepareTaggedUsers()
	 *
	 * This method is used on the web page to render a search form for finding users with certain tags. 
	 *
	 * The user will then get search results as he/she is typing a tag in the input field. 
	 * There is a requirement that there must be at least two characters before a search is performed,
	 * and there is also a delay on key up on 500ms, just to avoid firing searches all the time a key is pressed.
	 *
	 * @param: el 			A DOM element BUTTON. Used to get the user's token in the DOM
	 *
	 */

	MLAB.fn.prepareTaggedUsers = function(el)
	{
		var self = this;

		var token = $(el).closest('[data-token]')
		self.token = token.data('token');
		console.log("GETNEWUSERS", token.data('token'));

		var html = '<form action="javascript:return false;">\
			<input type="hidden" name="token" value="' + token.data('token') + '" />\
			<div style="margin-top: 20px">\
				<input class="input-lg" type="text" name="tag" value="" placeholder="Tag" data-mode="autocomplete" />\
			</div>\
		</form>\
		<div id="subcontent"></div>';

		$('#content').html(html);

		// Override the default autocomplete event listener
		$(document).off('input[data-mode=autocomplete]');
		$(document).on('keydown', 'input[data-mode=autocomplete]', function(e)
		{
			clearTimeout(self.timer);
			self.timer = null;
		});

		$(document).on('keyup', 'input[data-mode=autocomplete]', function(e)
		{
			clearTimeout(self.timer)
			self.timer = setTimeout(function(){ self.query() }, 700);
		});
	}

	/*
	 * query()
	 *
	 * This method will query the server for users tagged with the requested tag, by calling /getTaggedUsers.
	 *
	 * The tag is matched with wild cards to make it easier to get results.
	 * The result is parsed and the users rendered on the screen, also showing their current state.
	 *
	 * @params: No parameters, but the method will get the value from the autocomplete input field
	 * @result: json { success:true/false, users:[array of users] }
	 *
	 */

	MLAB.fn.query = function()
	{
		var self = this;
		var query = $('input[data-mode=autocomplete]').val();
		if (query == self.prevquery)
			return;

		self.prevquery = query;

		if (query.length > 1)
		{
			var data = { token:self.token, tag:query };
			$.ajax(
			{
				url : '/getTaggedUsers',
				type : 'get',
				data : data,
				cache : false,
				singleton: true,

				success : function(response)
				{
					var html = $('<ul data-token="' + self.token + '"></ul>');
					$.each(response.users, function(n, user)
					{
						html.append('<li data-id="' + user.id + '"><i class="fa fa-user"></i><div class="name">' + user.real_name + '<span>' + user.email + '</span></div><div class="big pull-right">' + user.state + '</div></li>');
					});

					$('#subcontent').html(html);

					if (response.users.length)
					{
						html = '<form action="javascript:return false;" data-tags="' + query + '" data-token="' + self.token + '" style="float: left; width: 100%; margin-top: 20px;"><select name="state"><option value="">Select state</option><option value="0">Disabled</option><option value="1">Enabled</option></select> <button type="button" class="btn btn-info" onclick="$MLAB.setTaggedUsersState(this)">setTaggedUsersState()</button></form>';
						$('#subcontent').append(html);
					}
				},

				error : function(error)
				{
					console.log("ERROR", error.statusText);
				}
			});
		}
	}

	/*
	 * createApp()
	 *
	 * This will call /submitAppDetails on the server and create a new app in the database.
	 *
	 * @params: No parameters, but data is pulled from the form and posted to the server using ajax.
	 * @result: json { success:true/false, appid:n }
	 *
	 */

	MLAB.fn.createApp = function()
	{
		var self = this;
		var form = $('form[data-action=create]');
		var token = $('input[name=token]', form).val();
		var name = $('input[name=name]', form).val();
		var uid = $('input[name=uid]', form).val();

		var fdata = new FormData(form[0]);
		$('#form-feedback').html('');

		var icon = $('input[name="icon"]').get(0).files;
		var screenshots = $('input[name="screenshots"]').get(0).files;

		// Validate required fields
		var valid = true;
		$('*[data-required]', form).each(function(n, field)
		{
			var field = $(field);
			if (!field.val())
			{
				self.showTooltip(field, '');
				valid = false;
			}
		});

		if (icon.length < 1)
		{
			$('#form-feedback').html('<div class="alert alert-danger">You must provide an app icon file (png-format)</div>');
			return;			
		}

		// Limit the number of files
		if (screenshots.length > MAX_SCREENSHOTS)
		{
			$('#form-feedback').html('<div class="alert alert-danger">You are only allowed to upload ' + MAX_SCREENSHOTS + ' screenshots</div>');
			return;
		}
		else if (screenshots.length < 1)
		{
			$('#form-feedback').html('<div class="alert alert-danger">You must provide at least one screenshot</div>');
			return;			
		}

		// If not all required fields are filled in, do not continue
		if (!valid)
			return;

		// Submit app details to the server
		$.ajax(
		{
			url : '/submitAppDetails',
			type : 'post',
			data : fdata,
			contentType: false,
			processData: false,
			cache : false,

			success : function(response)
			{
				console.log("SUCC", response);
				if (response.success === true)
					window.location = '/apps/' + response.appid;
				else
				{
					if (response.error)
					{
						$('#form-feedback').html('<div class="alert alert-danger">' + response.error + '</div>');
						if (response.field)
						{
							var field = $('*[name="' + response.field + '"]', form);
							self.showTooltip(field, response.fieldText);
						}						
						return;
					}
				}
			},

			error : function(error)
			{
				console.log("ERROR", error.statusText);
			}
		});
	}

	/*
	 * uploadAppFile()
	 *
	 * This method will upload the app binary to the server.
	 *
	 * @params: No parameters, but data is pulled from the form and posted to the server using ajax.
	 *
	 * Success:
	 * @result: json { success:true, uid:uid, version:version }
	 *
	 * Failure:
	 * @result: json { success:false, error:message }
	 *
	 */

	MLAB.fn.uploadAppFile = function()
	{
		var self = this;
		var form = $('form[data-action=uploadapp]');
		var token = $('input[name=token]', form).val();
		var replace = $('input[name=replace_existing]', form).prop('checked');
		var uid = $('input[name=uid]', form).val();

		var fdata = new FormData(form[0]);
		$('#form-feedback').html('');

		// Do not continue if a file hasn't been selected yet
		if ($('input[name="file"]').get(0).files.length === 0)
		{
			$('#form-feedback').html('<div class="alert alert-danger">You must provide an app file before you can upload...</div>');
			return;
		}

		console.log("UPLOAD", token, replace);
		$.ajax(
		{
			url : '/uploadAppFile',
			type : 'post',
			data : fdata,
			contentType: false,
			processData: false,
			cache : false,

			success : function(response)
			{
				console.log("SUCC", response);
				var section = form.closest('[data-token]');
				var token = section.data('token');

				if ($('form[data-action=publish]').length === 0)
				{
					var html = '<form data-action="publish" action="javascript:$MLAB.publishApp(this)" data-validate="yes" autocomplete="off">\
						<input name="token" value="' + token + '" type="hidden" />\
						<input name="uid" value="' + response.uid + '" type="hidden" />\
						<input name="version" value="' + response.version + '" type="hidden" />\
						<button class="btn btn-success left">Publish app</button>\
					</form>';

					$('form[data-action=uploadapp]').parent().append(html);
				}
			},

			error : function(error)
			{
				console.log("ERROR", error.statusText);
			}
		});

		console.log(form, token, name, uid);
	}

	/*
	 * publishApp()
	 *
	 * Will set the app state flag to published, by sending a put request to /publishApp on the server.
	 *
	 * @param: No parameters, but data for the request is pulled from the DOM (where token, uid and version is set as data-attributes)
	 * @result: json { success:true/false [, error:message] }
	 *
	 */

	MLAB.fn.publishApp = function()
	{
		var self = this;

		var form = $('form[data-action=publish]');
		var app = form.closest('.app');
		var section = form.closest('section[data-token]');
		var token = section.data('token');
		var uid = section.data('uid');
		var version = section.data('version');

		var data = { token:token, uid:uid, version:version };

		$.ajax(
		{
			url : '/publishApp',
			type : 'put',
			data : JSON.stringify(data),
			contentType: 'application/json',
			cache : false,

			success : function(response)
			{
				if ($('form[data-action=publish]').length !== 0)
				{
					$('form[data-action=publish]').remove();
					$('form[data-action=uploadapp]').hide();

					var html = '<form data-action="unpublish" action="javascript:$MLAB.unpublishApp(this)" data-validate="yes" autocomplete="off">\
						<button class="btn btn-warning left">Unublish app</button>\
					</form>';

					$('#actions').append(html);

					app.removeClass('staged').removeClass('hidden').removeClass('withdrawn');
					app.addClass('published');
				}
			},

			error : function(error)
			{
				console.log("ERROR", error.statusText);
			}
		});
	}

	/*
	 * unpublishApp()
	 *
	 * Will set the app state flag to the requested action (here it's set to hide), by sending a put request to /unpublishApp on the server.
	 *
	 * @param: No parameters, but data for the request is pulled from the DOM (where token, uid and version is set as data-attributes)
	 * @result: json { success:true/false [, error:message] }
	 *
	 */

	MLAB.fn.unpublishApp = function()
	{
		var self = this;

		var form = $('form[data-action=unpublish]');
		var app = form.closest('.app');
		var section = form.closest('section[data-token]');
		var token = section.data('token');
		var uid = section.data('uid');
		var version = section.data('version');
		var action = 'hide';

		var data = { token:token, uid:uid, version:version, action:action };

		$.ajax(
		{
			url : '/unpublishApp',
			type : 'put',
			data : JSON.stringify(data),
			contentType: 'application/json',
			cache : false,

			success : function(response)
			{
				var section = form.closest('[data-token]');
				var token = section.data('token');

				if ($('form[data-action=unpublish]').length !== 0)
				{
					$('form[data-action=unpublish]').remove();
					$('form[data-action=uploadapp]').show();

					var html = '<form data-action="publish" action="javascript:$MLAB.publishApp(this)" data-validate="yes" autocomplete="off">\
						<button class="btn btn-success left">Publish app</button>\
					</form>';

					$('#actions').append(html);

					console.log(response)
					app.removeClass('published').removeClass('hidden').removeClass('withdrawn');
					app.addClass('staged');
				}
			},

			error : function(error)
			{
				console.log("ERROR", error.statusText);
			}
		});
	}

	/*
	 * getApp()
	 *
	 * Will initiate a download of the app
	 *
	 * @param: No parameters, but data for the request is pulled from the DOM (token and uid)
	 * @result: file download
	 *
	 */

	MLAB.fn.getApp = function()
	{
		var self = this;
		var app = $('section.app');
		var token = app.data('token');
		var uid = app.data('uid');

		// Redirect the browser to the download url
		window.location = '/getApp?token=' + token + '&uid=' + uid
	}

	/*
	 * checkAppUpdate()
	 *
	 * Send a request to the server to see if there is a newer version of an app than the version in the request.
	 *
	 * @params: No parameters, but data for the request is pulled from the DOM (token, uid, version)
	 * Success:
	 * @result: json { success:true, uid:app.uid, name:app.name, version:app.version, update_notes:app.update_notes }
	 *
	 * Failure:
	 * @result: json { success:false }
	 *
	 */

	MLAB.fn.checkAppUpdate = function()
	{
		var self = this;
		var app = $('section.app');
		var token = app.data('token');
		var uid = app.data('uid');
		var version = $('#myversion').data('version');

		var data = { token:token, uid:uid, current_version:version };

		$.ajax(
		{
			url: '/checkAppUpdate',
			type: 'get',
			data: data,
			cache: false,

			success : function(response)
			{
				console.log("CHECKED", response);
				$('.dotted + .alert').remove();
				if (response.success === false)
				{
					$('.dotted').after('<div class="alert alert-success">You have the latest version</div>');
				}
				else
				{
					$('.dotted').after('<div class="alert alert-info">Version ' + response.version + ' is available as an update</div>');					
				}
			},

			error : function(error)
			{
				console.log("Error:", error.statusText);
			}
		});
	}

	/*
	 * search()
	 *
	 * Will call /search and query for apps matching a free text query.
	 *
	 * @params: No parameters, but will pull data for the request from the search form.
	 * @result: json { success:true/false, page:n, apps:[list of apps (limited to 10)] }
	 *
	 */

	MLAB.fn.search = function()
	{
		var self = this;

		var form = $('#search');
		var query = $('input[name=q]', form).val();
		var token = $('input[name=token]', form).val();
		var page = $('input[name=page]', form).val() || 1;
		var date_from = $('input[name=start]', form).val();
		var date_to = $('input[name=end]', form).val();

		var sp = { page:page, search_for:query };

		if (date_from)
			sp.date_from = date_from;

		if (date_to)
			sp.date_to = date_to;

		var data = { token:token, search_params:sp };
		console.log(sp)

		$.ajax(
		{
			url: '/search',
			type: 'get',
			data: data,
			cache: false,

			statusCode : {
				302 : function()
				{
					window.location = '/';
				}
			},

			success : function(response, statusText, jqxhr)
			{
				console.log("FOUND", response.apps.length);
				var html = '';
				$(response.apps).each(function(n, item)
				{
					html += '<li data-id="' + item.id + '"><a href="/apps/' + item.id + '"><figure style="background-image: url(/images/' + item.id + '/icon.png)" /></a><span>' + item.name + '</span></li>';
				});

				$('#page').html(html);
			},

			error : function(error)
			{
				console.log("Error:", error.statusText);
			}
		});
	}

	//
	//

	window.$MLAB = new MLAB();
	
	//
	//
}));

$(document).ready(function()
{
	var daterange = $('.input-daterange');
	if (daterange.length)
	{
		$('.input-daterange').datepicker({ format: "dd.mm.yyyy", calendarWeeks: true, todayHighlight: true, autoclose:true });
	}
})