/*
 * MLAB Market Application
 *
 * Developed by Snapper Net Solutions
 *
 * Copyright (C) 2015 Forsvarets Høgskole
 *
 */

var env = process.env.NODE_ENV || "development";

var express        = require('express'),
	passport       = require('passport'),
	models         = require('../models'),
	funct          = require('../functions'),

    config         = require('../config/config.json')[env];

var router = express.Router();
var menus = config.menus;

/*
 * Home page
 *
 * Render the front page for the MLAB market.
 * The template home.jade will render this differently if the user is signed in or not
 *
 */

router.get('/', function (req, res) {
	models.User.findAll().then(function(users) {
		var user = funct.getUser(req);

		// Get the menu according to the user's role
		var menu = user ? menus[user.role] : menus.default;

		// List newest apps (for now all...)
		models.App.findAll({ where:{ state:'published' }, limit:10 })
		.then(function(apps)
		{
			res.render('home', { title : 'Home', apps:apps, user:user, menu:menu });
		});
	});
});

/*
 * Image requests
 *
 * Images belong to apps, so we provide the id of the app as the :path parameter
 * The :filename parameter can be the id of a screenshot that is related to that app or just icon.png for the App icon
 *
 */

router.get('/images/:path/:filename', function (req, res) {
	models.User.findAll().then(function(users) {
		var user = funct.getUser(req);

		models.App.find({ where:{id:req.params.path}})
		.then(function(app)
		{
			// Icon?
			if (req.params.filename == 'icon.png')
			{
				var img = new Buffer( app.icon );
				res.writeHead(200, { 'Content-Type': 'image/png' });
				res.end(img, 'binary');
			}

			// Screenshot?
			else
			{
				models.Screenshot.find({ where:{ id:req.params.filename }})
				.then(function(file)
				{
					var img = new Buffer( file.image );
					res.writeHead(200, { 'Content-Type': file.type });
					res.end(img, 'binary');					
				});
			}
		});
	});
});

module.exports = router;