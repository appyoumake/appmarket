/*
 * MLAB Market Application
 *
 * Developed by Snapper Net Solutions
 *
 * Copyright (C) 2015 Forsvarets Høgskole
 *
 */

// Added these methods to the API:
// -------------------------------
// apps()

// Original methods in the API:
// -------------------------------
// submitAppDetails(app_details)
// uploadAppFile(token, uid, replace_existing) 		! Added token as a parameter
// publishApp(token, uid, version) 					! Added token as a parameter
// unpublishApp(token, uid, version, action) 		! Added token as a parameter

var env = process.env.NODE_ENV || "development";

var express        = require('express'),
	passport       = require('passport'),
	bcrypt         = require('bcryptjs'),
	formidable     = require('formidable'),
	mkdirp         = require('mkdirp'),
	fs             = require('fs'),
	path           = require('path'),
	mime           = require('mime'),

	models         = require('../models'),
	funct          = require('../functions'),

    config         = require('../config/config.json')[env];

var router = express.Router();
var menus = config.menus;

function bytesToSize(bytes) {
   if(bytes == 0) return '0 Byte';
   var k = 1000;
   var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
   var i = Math.floor(Math.log(bytes) / Math.log(k));
   return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
}

/*
 * apps
 * 
 * Render the Apps management page, where admin and superuser can create/upload new apps or publish/unpublish existing apps
 * 
 * Method: GET
 * Access: admin or superuser
 * @params: No parameters
 *
 */

router.get('/apps', function(req, res) {
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	// Get the menu according to the user's role
	var menu = menus.default;
	if (user)
		menu = menus[user.role];

	var max_apps = 10;
	if (user.role !== 'user')
		max_apps = 1000;

	models.App.findAll({ where:{ users_id:user.id }, limit:max_apps, order:'created DESC' })
	.then(function(apps)
	{
		res.render('apps', { title : 'Apps', menu:menu, user:user, apps:apps, active:'/apps' });
	});
});

/*
 * apps/:id
 * 
 * Render different pages of the app management
 * 
 * Method: GET
 * Access: useradmin or superuser
 * @params: id 	action or app id
 *
 * /apps/{id}
 *
 * Valid id parameters:
 * new 			-> Render the form for Create new app from the admin interface. The form will post to submitAppDetails()
 * [app id]		-> All: View a published app. Download/Check for update (added as a button to call checkAppUpdate())
 *                 Admin/Superuser: Upload app file and publish/unpublish app. Download/Check for update (added as a button to call checkAppUpdate())
 *
 */

router.get('/apps/:id', function(req, res) {
	var user = funct.getUser(req);
	if (!user)
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	// Get the menu according to the user's role
	var menu = menus.default;
	if (user)
		menu = menus[user.role];

	var id = req.params.id;

	// New app?
	if (id === 'new')
	{
		if (user.role !== 'user')
			res.render('apps_new', { title : 'New App', menu:menu, user:user, active:'/apps' });
		else
		{
			res.writeHead(302, {
				'Location': '/'
			});
			res.end();
			return;
		}
	}

	// Advanced app search
	else if (id == 'search')
	{
		res.render('apps_search', { title : 'Search Apps', menu:menu, user:user, active:'/apps' });		
	}

	// View app
	else
	{
		models.App.find({ where:{ id:id }, include:[{ model:models.Screenshot, as:'screenshots' }]})
		.then(function(app)
		{
			if (app)
			{
				models.User.find({ where:{ id:user.id }})
				.then(function(user_object)
				{
					user_object.getApps({ where:{ id:app.id }})
					.then(function(apps)
					{
						var size = bytesToSize(app.size);

						if (user.role == 'user')
							res.render('app', { title : 'App', menu:menu, user:user, app:app, mine:apps, size:size, active:'/apps' });
						else
							res.render('app_admin', { title : 'App', menu:menu, user:user, app:app, mine:apps, size:size, active:'/apps' });
					});
				});
			}
			else
			{
				res.writeHead(404, {'Content-Type': 'text/html'});
				res.render('404', { title:'404 - Page not found', menu:menu, user:user, active:'/apps' });
				res.end();
			}
		});
	}
});

/*
 * submitAppDetails
 * 
 * Create a new app in the database
 * 
 * Method: POST
 * Access: useradmin or superuser
 * @params: app_details (json: uid, name, description, update_notes, keywords, version, package_id, publisher_name, publisher_id, state, size, download_count, icon, superceded_by, screenshots, requirements, user_rating)
 *
 * Success:
 * @result: json { success:true, appid:n }
 *
 * Error:
 * @result: json { success:false, error:message }
 */

router.post('/submitAppDetails', function(req, res)
{
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	var filelist = [];

	// Get form data, including files
	var form = new formidable.IncomingForm();
	form.encoding = 'utf-8';
	form.uploadDir = "./uploads";
	form.keepExtensions = true;

	form.on('file', function(field, file)
	{
		if (field == 'screenshots')
			filelist.push(file);
	});

	form.parse(req, function(err, fields, files) {
		var token = fields.token;
		var uid = fields.uid;

		// If no name or uid, return error
		if (fields.name === '' || uid === '')
		{
			var result = { success:false, statusText:'Invalid name or uid' };
			res.writeHead(500, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
			return;
		}

		// Validate token
		if (user.token === token)
		{
			// Validate role
			if (user.role !== 'user')
			{
				var data = { uid: fields.uid, 
							 name: fields.name, 
							 description: fields.description || '',
							 update_notes: fields.update_notes || '',
							 package_id: fields.package_id,
							 publisher_name: fields.publisher_name,
							 publisher_id: fields.publisher_id,
							 state: 'staged',
							 version: '1.0',
							 requirements: fields.requirements,

							 users_id: user.id };

				var replace_existing = fields.replace_existing || false;

				// Insert the icon as a binary/blob
				if (files.icon)
				{
					var icon = fs.readFileSync(files.icon.path);
					data.icon = icon;
					fs.unlinkSync(files.icon.path);
				}

				models.App.find({ where:{ uid:fields.uid }})
				.then(function(app_exists)
				{
					if (app_exists)
					{
						var result = { success:false }
						console.log("APP ALREADY EXISTS", replace_existing)
						if (!replace_existing)
						{
							result.error = 'UID is not unique. An app with the UID=' + fields.uid + ' already exists.';
							result.field = 'uid';
							result.fieldText = 'UID already in use';

							res.writeHead(200, {'Content-Type': 'application/json'});
							res.write(JSON.stringify(result));
							res.end();
						}
						else
						{
							console.log("REPLACE APP")
						}
					}
					else
					{
						console.log("CREATING NEW APP", replace_existing);

						// Create the app
						models.App.create(data)
						.then(function(object)
						{
							var result = { 'success':false };

							// App was created successfully
							if (object)
							{
								// Update return values
								result.success = true;
								result.appid = object.dataValues.id;

								// Read the screenshots and insert into the database
								for (n in filelist)
								{
									var file = filelist[n];
									var filedata = { image:fs.readFileSync(file.path), filename:file.name, mimetype:file.type, size:file.size };
									fs.unlinkSync(file.path);

									models.Screenshot.create(filedata)
									.then(function(screenshot)
									{
										if (screenshot)
										{
											object.addScreenshot(screenshot);
										}
									});
								};
							}
							else
							{
								result.error = 'Unable to create app';
							}

							res.writeHead(200, {'Content-Type': 'application/json'});
							res.write(JSON.stringify(result));
							res.end();
						});
					}
				});
			}
		}
	});
});

/*
 * uploadAppFile
 * 
 * Upload the binary for the app
 * 
 * Method: POST
 * Access: useradmin or superuser
 * @params: token, uid, replace_existing
 *
 * Success:
 * @result: json { success:true, uid:uid, version:version }
 *
 * Error:
 * @result: json { success:false, error:message }
 */

router.post('/uploadAppFile', function(req, res)
{
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	// Get form data, including file
	var form = new formidable.IncomingForm();
	form.encoding = 'utf-8';
	form.uploadDir = "./uploads";
	form.keepExtensions = true;

	form.parse(req, function(err, fields, files) 
	{
		var token = fields.token;
		var uid = fields.uid;
		var version = fields.version;
		console.log(fields, files)

		console.log("UPLOAD FILE TO ./appfiles/uid/v", token, uid, version);

		// If no name or uid, return error
		if (!files.file || !uid)
		{
			var result = { success:false, statusText:'Invalid name or uid' };
			res.writeHead(500, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
			return;
		}

		// Validate token
		if (user.token === token)
		{
			// Validate role
			if (user.role !== 'user')
			{
				models.App.find({ where:{ uid:uid, version:version }})
				.then(function(object)
				{
					if (object)
					{
						object.size = files.file.size;
						object.save();
						console.log("UPDATE SIZE");
					}

					console.log("MOVE FILE...");
					fs.rename(files.file.path, './appfiles/' + uid, function(err)
					{
						var status = 500;
						var result = { success:false };
						if (!err)
						{
							status = 200;
							result.success = true;
							result.uid = uid;
							result.version = version;
						}
						res.writeHead(status, {'Content-Type': 'application/json'});
						res.write(JSON.stringify(result));
						res.end();
					});
				});
			}
		}
		else
		{
			var result = { success:false, statusText:'Invalid token' };
			res.writeHead(500, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	});
});

/*
 * publishApp
 * 
 * Publish an app by setting the state to published
 * 
 * Method: PUT
 * Access: useradmin or superuser
 * @params: token, uid, version
 *
 * Success:
 * @result: json { success:true }
 *
 * Failure:
 * @result: json { success:false }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.put('/publishApp', function(req, res)
{
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	var token = req.body.token;
	var uid = req.body.uid;
	var version = req.body.version;

	var result = { success:false }

	// Validate token
	if (user.token === token)
	{
		// Validate role
		if (user.role !== 'user')
		{
			models.App.find({ where:{ uid:uid, version:version }})
			.then(function(object)
			{
				var status = 500;
				if (object)
				{
					object.state = 'published';
					object.save();

					status = 200;
					result.success = true;

					console.log("PUBLISHED");
				}

				res.writeHead(status, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
				return;
			});
		}
		else
		{
			res.writeHead(500, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		res.writeHead(500, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

/*
 * unpublishApp
 * 
 * Unpublish an app by setting the state based on the action parameter
 * 
 * Method: PUT
 * Access: useradmin or superuser
 * @params: token, uid, version, action
 *
 * Success:
 * @result: json { success:true }
 *
 * Failure:
 * @result: json { success:false }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.put('/unpublishApp', function(req, res)
{
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	var token = req.body.token;
	var uid = req.body.uid;
	var version = req.body.version;
	var action = req.body.action;
	var state = null;

	switch(action)
	{
		case "hide":
			state = 'hidden';
			break;

		case "withdraw":
			state = 'withdrawn';
			break;
	}

	console.log("UNPUB", token, uid, version, action);
	var result = { success:false }

	// Validate token
	if (user.token === token && state !== null)
	{
		// Validate role
		if (user.role !== 'user')
		{
			models.App.find({ where:{ uid:uid, version:version }})
			.then(function(object)
			{
				var status = 500;
				if (object)
				{
					object.state = state;
					object.save();

					status = 200;
					result.success = true;

					console.log("UNPUBLISHED");
				}

				res.writeHead(status, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
				return;
			});
		}
		else
		{
			res.writeHead(500, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		res.writeHead(500, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

/*
 * getApp
 * 
 * Download the app
 * 
 * Method: GET
 * Access: user, useradmin or superuser
 * @params: token, uid
 *
 * Success:
 * @result: sends a stream of binary data to the user
 *
 * Error:
 * Not handled
 *
 */

router.get('/getApp', function(req, res)
{
	var user = funct.getUser(req);
	if (!user)
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	var token = req.query.token;
	var uid = req.query.uid;

	console.log("DOWNLOAD", token, uid);

	// Validate token
	if (user.token === token)
	{
		models.App.find({ where:{ uid:uid }})
		.then(function(object)
		{
			console.log("DOWNLOAD", object.uid);
			// Send the file to the user
			var file = './appfiles/' + uid;

			var filename = path.basename(file);
			var mimetype = mime.lookup(file);

			console.log("MIME", filename, mimetype);

			res.setHeader('Content-disposition', 'download; filename=' + object.name + '.zip');
			res.setHeader('Content-type', mimetype);

			var filestream = fs.createReadStream(file);
			filestream.pipe(res);

			// Increase the download count
			object.download_count++;
			object.save();

			// Add an entry to the user/app table
			models.User.find({ where:{ id:user.id }})
			.then(function(user_object)
			{
				if (user_object)
				{
					user_object.addApp(object, { version: object.version });
				}
			});
		});
	}
});

/*
 * checkAppUpdate
 * 
 * Check if an app is newer than the requested version number
 * 
 * Method: GET
 * Access: user, useradmin or superuser
 * @params: token, uid, current_version
 *
 * Success:
 * @result: json { success:true, uid:app.uid, name:app.name, version:app.version, update_notes:app.update_notes }
 *
 * Failure:
 * @result: json { success:false }
 *
 */

router.get('/checkAppUpdate', function(req, res)
{
	var user = funct.getUser(req);
	if (!user)
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	var token = req.query.token;
	var uid = req.query.uid;
	var version = req.query.current_version;

	console.log("CHECK VERSION", token, uid, version);

	// Validate token
	if (user.token === token)
	{
		models.App.find({ where:{ uid:uid }})
		.then(function(object)
		{
			var result = { error:'Unable to find object' };

			if (object)
			{
				result = { success:false };
				console.log("CHK V", object.version, version, object.version > version)

				if (object.version > version)
				{
					result = { success:true, uid:object.uid, name:object.name, version:object.version, update_notes:object.update_notes };
				}

				res.writeHead(200, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
			}
			else
			{
				res.writeHead(500, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
			}
		});
	}
});

/*
 * search
 * 
 * Search for apps
 * 
 * Method: GET
 * Access: user, useradmin or superuser
 * @params: token, search_params
 * @result: json { success:true/false, page:n, apps:[list of apps (limited to 10)] }
 *
 */

router.get('/search', function(req, res)
{
	var user = funct.getUser(req);
	if (!user)
	{
		res.writeHead(302, {'Content-Type': 'application/json'});
		res.write(JSON.stringify({ success:false }));
		res.end();
		return;
	}

	var token = req.query.token;
	var search_params = req.query.search_params;

	var search_for = req.query.search_params.search_for;
	var page = req.query.search_params.page || 1;
	var date_from = req.query.search_params.date_from || null;
	var date_to = req.query.search_params.date_to || null;
	var categories = [];
	var apps_per_page = 10;
	var p = page - 1;
	if (p < 0) p = 0;
	var offset = p * apps_per_page;

	// Handle date created from
	if (date_from)
	{
		date_from = date_from.split('.');
		date_from = new Date(date_from[2], parseInt(date_from[1]) - 1, date_from[0], 0, 0);

		// Make sure we get the date as UTC
		var tz_offset = date_from.getTimezoneOffset() * -1;
		date_from.setMinutes(date_from.getMinutes() + tz_offset);
	}

	// Handle date created to
	if (date_to)
	{
		date_to = date_to.split('.');
		date_to = new Date(date_to[2], parseInt(date_to[1]) - 1, date_to[0]);

		// Make sure we get the date as UTC
		var tz_offset = date_from.getTimezoneOffset() * -1;
		date_to.setMinutes(date_to.getMinutes() + tz_offset);
	}

	// Perform search
	var dbquery = { where:["(name LIKE '%" + search_for + "%' OR publisher_name LIKE '%" + search_for + "%' OR description LIKE '%" + search_for + "%' OR update_notes LIKE '%" + search_for + "%') AND state='published'" + (date_from ? ' AND created > "' + date_from.toISOString() + '"' : '') + (date_to ? ' AND created < "' + date_to.toISOString() + '"' : '')], limit:apps_per_page, offset:offset }
	models.App.findAll(dbquery)
	.then(function(hits)
	{
		var result = { success:false, page:page, apps:[] };

		if (hits)
		{
			result.success = true;

			for (i in hits)
			{
				var app = {};
				app.name = hits[i].name;
				app.id = hits[i].id;
				app.uid = hits[i].uid;
				app.description = hits[i].description || '';
				app.update_notes = hits[i].update_notes || '';
				app.version = hits[i].version;
				app.download_count = hits[i].download_count;

				result.apps.push(app);
			};

			res.writeHead(200, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
		else
		{
			res.writeHead(200, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();			
		}
	});
});

module.exports = router;