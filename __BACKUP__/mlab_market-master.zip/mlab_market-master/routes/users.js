/*
 * MLAB Market Application
 *
 * Developed by Snapper Net Solutions
 *
 * Copyright (C) 2015 Forsvarets Høgskole
 *
 */

// Added these methods to the API:
// -------------------------------
// signup()
// signin()
// logout()
// users()
// getTaggedUsers(token, tag)

// Original methods in the API:
// -------------------------------
// login(username, password)
// createUser(token, user_details)
// getNewUsers(token)
// setUserState(token, uid, state)			! Added token as a parameter
// setTaggedUsersState(token, tag, state)

var env = process.env.NODE_ENV || "development";

var express        = require('express'),
	passport       = require('passport'),
	bcrypt         = require('bcryptjs'),
	models         = require('../models'),
	funct          = require('../functions'),

    config         = require('../config/config.json')[env];

var router = express.Router();
var menus = config.menus;

/*
 * signup
 * 
 * Render the form for signing up as a new user (new_user.jade)
 * 
 * Method: GET
 * @params: No parameters
 *
 */

router.get('/signup', function (req, res) {
	var user = funct.getUser(req);

	// Get the menu according to the user's role
	var menu = menus.default;
	if (user)
		menu = menus[user.role];

	res.render('new_user', { title:'Sign up' , menu:menu, active:'/signup' });
});

/*
 * signup
 *
 * Register a new user from the signup form if user does not exists
 *
 * Method: POST
 * @params: email, realname, password
 *
 * Success:
 * @result: json { success:true, userid:int }
 *
 * Failure:
 * @result: json { success:false }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.post('/signup', function(req, res) {
	var email = req.body.email;

	models.User.find({ where: { email:email }} )
	.then(function(object)
	{
		if (!object)
		{
			// Create the user
			var data = { 'email':req.body.email, 'real_name':req.body.realname };
			models.User.create(data)
			.then(function(object)
			{
				console.log("CREATING USER")
				var result = { 'success':false };
				if (object)
				{
					result['success'] = true;
					result['userid'] = object.dataValues.id;

					// Generate password
					var salt = bcrypt.genSaltSync(10);
					var hash = bcrypt.hashSync(req.body.password, salt);
					var pwd = { 'passwd':hash };

					models.Password.create(pwd)
					.then(function(password)
					{
						if (password != null)
						{
							// Connect the password to the user
							object.setPassword(password);

							result['success'] = true;
							result['userid'] = object.dataValues.id;

							res.writeHead(200, {'Content-Type': 'application/json'});
							res.write(JSON.stringify(result));
							res.end();
						}
					});
				}
				else
				{
					result['error'] = 'Unable to create user object';

					res.writeHead(200, {'Content-Type': 'application/json'});
					res.write(JSON.stringify(result));
					res.end();
				}
			});
		}
		else
		{
			console.log("USER ALREADY EXISTS")
			var result = { 'success':false, 'error':'User already exists' };

			res.writeHead(200, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	});
});

/*
 * signin
 *
 * Render the sign in form (signin.jade)
 * 
 * Method: GET
 * @params: No parameters
 *
 */

router.get('/signin', function (req, res) {
	var user = funct.getUser(req);

	// Get the menu according to the user's role
	var menu = menus.default;
	if (user)
		menu = menus[user.role];

	res.render('signin', { title : 'Sign in', menu:menu, active:'/signin' });
});

/*
 * login
 *
 * Sign in a user
 *
 * Method: POST
 * @params: username, password
 *
 */

router.post('/login', passport.authenticate('local-signin', { 
		successRedirect: '/',
		failureRedirect: '/signin'
	})
);

/*
 * logout
 *
 * Sign out the user
 *
 * Method: GET
 * @params: No parameters
 *
 */

router.get('/logout', function(req, res){
  req.logout();
  res.redirect('/');
});


/*
 * users
 *
 * Render the User management page (users.jade)
 *
 * Method: GET
 * Access: admin or superuser
 * @params: No parameters
 *
 */

router.get('/users', function (req, res) {
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	// Get the menu according to the user's role
	var menu = menus.default;
	if (user)
		menu = menus[user.role];

	// Count the total number of users
	models.User.count()
	.then(function(total)
	{
		// Count the number of new self registered users
		models.User.count({ where:{ state:99 }})
		.then(function(newusers)
		{
			// Count the number of disabled users
			models.User.count({ where:{ state:0 }})
			.then(function(disabledusers)
			{
				res.render('users', { title : 'Users', menu:menu, user:user, active:'/users', totalusers:total, newusers:newusers, disabledusers:disabledusers });
			});
		});
	});
});

/*
 * users/:id
 *
 * Render different pages for user management
 *
 * Method: GET
 * Access: admin or superuser
 * @params: id 	action or userid
 *
 * /users/{id}
 *
 * Valid id parameters:
 * new 			-> Render the form for Create new user from the admin interface. Will call createUser()
 * [userid]		-> Edit a user : NOT IMPLEMENTED
 *
 */

router.get('/users/:id', function (req, res) {
	var user = funct.getUser(req);
	if (!user || user.role == 'user')
	{
		res.writeHead(302, {
			'Location': '/'
		});
		res.end();
		return;
	}

	// Get the menu according to the user's role
	var menu = menus.default;
	if (user)
		menu = menus[user.role];

	var id = req.params.id;

	if (id === 'new')
	{
		res.render('users_new', { title : 'New User', menu:menu, user:user, active:'/users' });
	}
	/*
	else if (id === 'validate')
	{
		var query = db.query('SELECT * FROM users WHERE state=99', function(err, rows, fields) {
			var user = funct.getUser(req);

			// Render the page
			res.render('users_validate', { title : 'Validate Users', users:rows, user:user, menu:menu, active:'/users' });
		});
	}
	else
	{
		var query = db.query('SELECT * FROM users WHERE id=' + req.params.id, function(err, rows, fields) {
			var user = funct.getUser(req);

			// Get the menu according to the user's role
			var menu = menus.default;
			if (user)
				menu = menus[user.role];

			var object = {};
			if (rows.length)
				object = rows[0];

			// Render the page
			res.render('users_edit', { title : 'Validate Users', users:rows, user:user, object:object, menu:menu, active:'/users' });
		});
	}
	*/
});

/* 
 * createUser
 *
 * Create a user
 *
 * Method: POST
 * Access: admin or superuser
 * @params: token, user_details (json: email, realname, role, location, tags, category (NOT IMPLEMENTED))
 *
 * Success:
 * @result: json { success:true, userid:n }
 *
 * Failure:
 * @result: json { success:false }
 *
 * Error 
 * @result: json { success:false, error:message }
 *
 */

router.post('/createUser', function(req, res) {
	var user = funct.getUser(req);

	var token = req.body.token;

	// Validate token
	if (user.token === token)
	{
		// Validate role
		if (user.role !== 'user')
		{
			var user_details = req.body.user_details;
			var email = user_details.email;

			models.User.find({ where: { email:email }} )
			.then(function(object)
			{
				if (!object)
				{
					console.log("CREATE NEW USER");
					var data = { 'email':email, 'real_name':user_details.realname, 'state':1, 'role':user_details.role, 'location':user_details.location, 'tags':user_details.tags };

					// Create the user
					models.User.create(data)
					.then(function(object)
					{
						var result = { 'success':false };

						if (object)
						{
							// Generate password
							var salt = bcrypt.genSaltSync(10);
							var hash = bcrypt.hashSync(user_details.password, salt);
							var pwd = { 'passwd':hash };

							models.Password.create(pwd)
							.then(function(password)
							{
								if (password != null)
								{
									// Connect password to the user
									object.setPassword(password);

									result['success'] = true;
									result['userid'] = object.dataValues.id;

									res.writeHead(200, {'Content-Type': 'application/json'});
									res.write(JSON.stringify(result));
									res.end();
								}
							});
						}
						else
						{
							result['error'] = 'Unable to create user object';

							res.writeHead(200, {'Content-Type': 'application/json'});
							res.write(JSON.stringify(result));
							res.end();
						}
					});
				}
				else
				{
					console.log("USER ALREADY EXISTS")
					var result = { 'success':false, 'error':'User already exists' };

					res.writeHead(200, {'Content-Type': 'application/json'});
					res.write(JSON.stringify(result));
					res.end();
				}
			});
		}
		else
		{
			var result = { 'success':false, 'error':'No access' };
			res.writeHead(403, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		var result = { 'success':false, 'error':'No access' };
		res.writeHead(403, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

/*
 * getNewUsers
 * 
 * Get a list of users with state=99
 *
 * Method: GET
 * Access: admin or superuser
 * @params: token
 *
 * Success:
 * @result: json { success:true, users:[array with users] }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.get('/getNewUsers', function(req, res) {
	var token = req.query.token;
	var user = funct.getUser(req);

	// Validate token
	if (user.token === token)
	{
		// Validate role
		if (user.role !== 'user')
		{
			models.User.findAll({ where: { state:99 }}).then(function(users)
			{
				var result = { 'success':true, 'users':[] };
				for (i in users)
				{
					result.users.push(users[i]);
				};

				res.writeHead(200, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
			});
		}
		else
		{
			var result = { 'success':false, 'error':'No access' };
			res.writeHead(403, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		var result = { 'success':false, 'error':'No access' };
		res.writeHead(403, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

/*
 * getTaggedUsers
 * 
 * Get a list of users containing a tag like the requested tag (will match using wildcards)
 *
 * Method: GET
 * Access: admin or superuser
 * @params: token, tag
 *
 * Success:
 * @result: json { success:true, users:[array of users] }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.get('/getTaggedUsers', function(req, res) {
	var token = req.query.token;
	var tag = req.query.tag;
	var user = funct.getUser(req);

	// Validate token
	if (user.token === token)
	{
		// Validate role
		if (user.role !== 'user')
		{
			// Find all users matching the query
			models.User.findAll({ where: ["tags like '%" + tag + "%'"]})
			.then(function(users)
			{
				var result = { 'success':true, 'users':[] };
				for (i in users)
				{
					result.users.push(users[i]);
				};

				res.writeHead(200, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
			});
		}
		else
		{
			var result = { 'success':false, 'error':'No access' };
			res.writeHead(403, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		var result = { 'success':false, 'error':'No access' };
		res.writeHead(403, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

/*
 * setUserState
 * 
 * Set a user state to enabled or disabled
 *
 * Method: PUT
 * Access: admin or superuser
 * @params: token, uid, state
 *
 * Success:
 * @result: json { success:true }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.put('/setUserState', function(req, res) {
	var user = funct.getUser(req);
	var token = req.body.token;
	var state = req.body.state;
	var uid = req.body.uid;

	// Validate token
	if (user.token === token)
	{
		// Validate role
		if (user.role !== 'user')
		{
			// Enable or disable the user
			models.User.find({ where: { id:uid }}).then(function(object)
			{
				object.state = state;
				object.save();

				var result = { 'success':true };
				res.writeHead(200, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
			});
		}
		else
		{
			var result = { 'success':false, 'error':'No access' };
			res.writeHead(403, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		var result = { 'success':false, 'error':'No access' };
		res.writeHead(403, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

/*
 * setTaggedUsersState
 * 
 * Enable or disable a set of users matching the requested tag
 *
 * Method: PUT
 * Access: admin or superuser
 * @params: token, tag, state
 *
 * Success:
 * @result: json { success:true, users:[array with updated users] }
 *
 * Error:
 * @result: json { success:false, error:message }
 *
 */

router.put('/setTaggedUsersState', function(req, res) {
	var token = req.body.token;
	var tag = req.body.tag;
	var state = req.body.state;
	var user = funct.getUser(req);

	// Validate token
	if (user.token === token)
	{
		// Validate role
		if (user.role !== 'user')
		{
			models.User.findAll({ where: ["tags like '%" + tag + "%'"]}).then(function(users)
			{
				var result = { 'success':true, 'users':[] };
				for (i in users)
				{
					users[i].state = state;
					users[i].save();

					// Add the updated user data to the result
					result.users.push(users[i]);
				};

				res.writeHead(200, {'Content-Type': 'application/json'});
				res.write(JSON.stringify(result));
				res.end();
			});
		}
		else
		{
			var result = { 'success':false, 'error':'No access' };
			res.writeHead(403, {'Content-Type': 'application/json'});
			res.write(JSON.stringify(result));
			res.end();
		}
	}
	else
	{
		var result = { 'success':false, 'error':'No access' };
		res.writeHead(403, {'Content-Type': 'application/json'});
		res.write(JSON.stringify(result));
		res.end();
	}
});

module.exports = router;