/*
 * MLAB Market Application
 *
 * Developed by Snapper Net Solutions
 *
 * Copyright (C) 2015 Forsvarets Høgskole
 *
 */

/*
 * Module dependencies
 */

var env = process.env.NODE_ENV || "development";

var mysql          = require('mysql'),
    express        = require('express'),
    stylus         = require('stylus'),
    jade           = require('jade'),
    nib            = require('nib'),
    path           = require('path'),
    logger         = require('morgan'),
    bodyParser     = require('body-parser'),
    passport       = require('passport'),
    LocalStrategy  = require('passport-local'),
    cookieParser   = require('cookie-parser'),
    session        = require('express-session'),
    methodOverride = require('method-override'),    

    funct          = require('./functions.js'),
    config         = require(__dirname + '/config/config.json')[env];

    routes         = require('./routes/index'),
    users          = require('./routes/users'),
    apps           = require('./routes/apps')

/*
 * Configure MySQL database connection
 */

var db = mysql.createConnection({
  host     : '127.0.0.1',
  user     : config.username,
  password : config.password,
  database : config.database
});

// Connect to the database
db.connect();


//
// Set up the app to use Express (Web application framework) 
//

var app = express();

// Set up Stylus (SASS/SCSS compiler)
function compile(str, path) {
  return stylus(str)
    .set('filename', path)
    .use(nib())
}

// Set up where our views are (using Jade templates)
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

//app.use(express.logger('dev'));
app.use(stylus.middleware(
  { src: __dirname + '/public'
  , compile: compile
  }
))

// Set up a logger
app.use(logger('dev'));

// Set up data parsers for incoming requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

app.use(express.static(path.join(__dirname, 'public')));

app.use(methodOverride('X-HTTP-Method-Override'));
app.use(session({secret: 'smackarooney', saveUninitialized: true, resave: true, cookie:{ maxAge:20*60000 } }));

// Set up passport for handling authentication
app.use(passport.initialize());
app.use(passport.session());

/*
 * Application routes
 */

app.use('/', routes);
app.get('/images/:path/:filename', routes);

app.get('/signup', users);
app.post('/signup', users);
app.get('/signin', users);
app.post('/login', users);
app.get('/logout', users);
app.get('/users', users);
app.get('/users/:id', users);
app.get('/getNewUsers', users);
app.post('/createUser', users);
app.put('/setUserState', users);
app.get('/getTaggedUsers', users);
app.put('/setTaggedUsersState', users);

app.get('/apps', apps);
app.get('/apps/:id', apps);
app.post('/submitAppDetails', apps);
app.post('/uploadAppFile', apps);
app.put('/publishApp', apps);
app.put('/unpublishApp', apps);
app.get('/getApp', apps);
app.get('/checkAppUpdate', apps);
app.get('/search', apps);

// Session-persisted message middleware
app.use(function(req, res, next)
{
  var err = req.session.error,
      msg = req.session.notice,
      success = req.session.success;

  delete req.session.error;
  delete req.session.success;
  delete req.session.notice;

  if (err) res.locals.error = err;
  if (msg) res.locals.notice = msg;
  if (success) res.locals.success = success;

  next();
});


//=============== PASSPORT =================//

// Use the LocalStrategy within Passport to login/”signin” users.
passport.use('local-signin', new LocalStrategy(
{
	passReqToCallback : true}, //allows us to pass back the request to the callback
	function(req, username, password, done) 
	{
	    funct.localAuth(username, password, db)
	    .then(function (user) {
	      if (user) {
	        console.log("LOGGED IN AS: " + user.username);
	        req.session.success = 'You are successfully logged in ' + user.username + '!';
	        done(null, user);
	      }
	      if (!user) {
	        console.log("COULD NOT LOG IN");
	        req.session.error = 'Could not log user in. Please try again.'; //inform user could not log them in
	        done(null, user);
	      }
	    })
	    .fail(function (err){
	      console.log("ERRRR", err.body);
	    });
	})
);

// Passport session setup.
passport.serializeUser(function(user, done) {
  console.log("serializing " + user.username);
  done(null, user);
});

passport.deserializeUser(function(obj, done) {
  console.log("deserializing " + obj);
  done(null, obj);
});


// Server will listen to port ?
app.listen(config.port_number);

module.exports = app;
