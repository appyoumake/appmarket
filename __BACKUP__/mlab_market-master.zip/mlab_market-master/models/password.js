"use strict";

module.exports = function(sequelize, DataTypes) {
  var Password = sequelize.define("Password", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    passwd: DataTypes.STRING,
    users_id: DataTypes.INTEGER
  }, {
    tableName: 'passwords',
    timestamps: false,
    classMethods: {
    }
  });

  return Password;
};