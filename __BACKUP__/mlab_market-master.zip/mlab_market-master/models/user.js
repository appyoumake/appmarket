"use strict";

module.exports = function(sequelize, DataTypes) {
  var User = sequelize.define("User", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    email: DataTypes.STRING,
    real_name: DataTypes.STRING,
    role: DataTypes.STRING,
    location: DataTypes.STRING,
    state: DataTypes.INTEGER,
    tags: DataTypes.STRING
  }, {
    tableName: 'users',
    timestamps: false,
    classMethods: {
      associate:function(models){
        User.hasOne(models.Password, { as:'password', foreignKey: 'users_id' });
        User.belongsToMany(models.App, { through: models.UserDownload, foreignKey:'users_id' });
      }
    }
  });

  return User;
};