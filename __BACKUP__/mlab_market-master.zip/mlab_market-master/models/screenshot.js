"use strict";

module.exports = function(sequelize, DataTypes) {
  var Screenshot = sequelize.define("Screenshot", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    apps_id: DataTypes.INTEGER,
    image: DataTypes.BLOB,
    filename: DataTypes.STRING,
    mimetype: DataTypes.STRING,
    size: DataTypes.INTEGER
  }, 

  {
    tableName: 'screenshots',
    timestamps: false,
    classMethods: {
    }
  });

  return Screenshot;
};