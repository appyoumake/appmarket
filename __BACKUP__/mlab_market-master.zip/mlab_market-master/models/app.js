"use strict";

module.exports = function(sequelize, DataTypes) {
  var App = sequelize.define("App", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    uid: DataTypes.STRING,
    name: DataTypes.STRING,
    description: DataTypes.TEXT,
    update_notes: DataTypes.TEXT,
    version: DataTypes.INTEGER,
    package_id: DataTypes.STRING,
    created: DataTypes.DATE,
    publisher_name: DataTypes.STRING,
    publisher_id: DataTypes.STRING,
    state: DataTypes.STRING,
    size: DataTypes.INTEGER,
    download_count: DataTypes.INTEGER,
    icon: DataTypes.BLOB,
    superceded_by: DataTypes.STRING,
    requirements: DataTypes.STRING,
    user_rating: DataTypes.INTEGER
  }, 

  {
    tableName: 'apps',
    timestamps: false,
    classMethods: {
      associate:function(models){
          App.belongsTo(models.User, { as:'owner', foreignKey: 'users_id' });
          App.hasMany(models.Screenshot, { as:'screenshots', foreignKey:'apps_id' });
          App.belongsToMany(models.User, { through: models.UserDownload, foreignKey:'apps_id' });
      }
    }
  });

  return App;
};