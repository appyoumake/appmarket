"use strict";

module.exports = function(sequelize, DataTypes) {
  var UserDownload = sequelize.define("UserDownload", {
    users_id: DataTypes.INTEGER,
    apps_id: DataTypes.INTEGER,
    version: DataTypes.STRING
  }, {
    tableName: 'users_downloaded_apps',
    timestamps: false,
    classMethods: {
    }
  });

  return UserDownload;
};