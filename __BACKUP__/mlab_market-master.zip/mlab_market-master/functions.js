/*
 * MLAB Market Application
 *
 * Developed by Snapper Net Solutions
 *
 * Copyright (C) 2015 Forsvarets Høgskole
 *
 */

/*
 * Module dependencies
 */

var bcrypt = require('bcryptjs'),
	crypto = require('crypto'),
    Q      = require('q')

exports.localAuth = function (username, password, db) 
{
	var deferred = Q.defer();

	var query = db.query('SELECT * FROM users WHERE email="' + username + '"', function(err, rows, fields) {
		// Look up the user
		if (rows.length === 0 || rows[0].state == 0)
		{
			console.log("NO SUCH USER")
			deferred.resolve(false);
		}
		else
		{
			var q2 = db.query('SELECT passwd FROM passwords WHERE users_id=' + rows[0].id, function(error, row)
			{
				if (row)
				{
					var hash = row[0].passwd;
					if (bcrypt.compareSync(password, hash))
					{
						// Create token
						var token = exports.generateToken(username);
						var q3 = db.query('INSERT INTO tokens SET token="' + token + '", users_id=' + rows[0].id, function(error, row)
						{
							//console.log("TOKEN", error, row);
						});

						// If the user isn't validated, treat as regular unvalidated user
						var role = rows[0].role;
						if (rows[0].state == 99)
							role = 'user';

						// Return a user object that will be available in the request session
						var user = { username:username, id:rows[0].id, role:role, token:token, real_name:rows[0].real_name };
						deferred.resolve(user);
					}
					else
					{
						deferred.resolve(false);
						console.log("FAILED")
					}
				}
			});
		}
	});

	return deferred.promise;
}

/*
 * getUser()
 *
 * Return the authenticated user object, if any, from the request
 *
 * @params: req 	the request structure
 * @result: user or null
 * 
 */
exports.getUser = function(req)
{
	var user = null;
	if (req.session.passport)
		user = req.session.passport.user;

	return user;
}

/*
 * generateToken()
 *
 * Generate a token for the authenticated user
 *
 * @params: s 		username
 * @result: md5 digest in hex format
 *
 */

exports.generateToken = function(s)
{
	var d = new Date();
	var h = crypto.createHash('md5');
	if (s)
		h.update(s);
	h.update('' + d.getTime());

	return h.digest('hex');
}
