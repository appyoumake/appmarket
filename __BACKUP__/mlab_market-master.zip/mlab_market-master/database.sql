SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';


-- -----------------------------------------------------
-- Table `users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `users` ;

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `real_name` VARCHAR(255) NULL,
  `role` VARCHAR(20) NULL DEFAULT 'user',
  `state` INT NULL DEFAULT 99,
  `location` VARCHAR(255) NULL,
  `category1` INT NULL,
  `category2` INT NULL,
  `category3` INT NULL,
  `tags` VARCHAR(255) NULL,
  PRIMARY KEY (`id`, `email`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `apps`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `apps` ;

CREATE TABLE IF NOT EXISTS `apps` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `users_id` INT NULL,
  `uid` VARCHAR(255) NULL,
  `name` VARCHAR(255) NULL,
  `description` TEXT NULL,
  `update_notes` TEXT NULL,
  `version` VARCHAR(25) NULL DEFAULT 1,
  `package_id` INT NULL,
  `created` TIMESTAMP NULL DEFAULT now(),
  `publisher_name` VARCHAR(255) NULL,
  `publisher_id` VARCHAR(255) NULL,
  `state` VARCHAR(10) NULL,
  `size` INT NULL DEFAULT 0,
  `download_count` INT NULL DEFAULT 0,
  `icon` MEDIUMBLOB NULL,
  `superceded_by` VARCHAR(255) NULL,
  `requirements` VARCHAR(10) NULL,
  `user_rating` INT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX `fk_apps_users1_idx` (`users_id` ASC),
  CONSTRAINT `fk_apps_users1`
    FOREIGN KEY (`users_id`)
    REFERENCES `users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `screenshots`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `screenshots` ;

CREATE TABLE IF NOT EXISTS `screenshots` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `apps_id` INT NULL,
  `image` MEDIUMBLOB NULL,
  `filename` VARCHAR(255) NULL,
  `mimetype` VARCHAR(50) NULL,
  `size` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_screenshots_apps_idx` (`apps_id` ASC),
  CONSTRAINT `fk_screenshots_apps`
    FOREIGN KEY (`apps_id`)
    REFERENCES `apps` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `keywords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `keywords` ;

CREATE TABLE IF NOT EXISTS `keywords` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `categories`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `categories` ;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `parent` INT NULL,
  `name` VARCHAR(255) NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_categories_categories1_idx` (`parent` ASC),
  CONSTRAINT `fk_categories_categories1`
    FOREIGN KEY (`parent`)
    REFERENCES `categories` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `passwords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `passwords` ;

CREATE TABLE IF NOT EXISTS `passwords` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `users_id` INT NULL,
  `passwd` VARCHAR(255) NULL,
  `created` TIMESTAMP NULL DEFAULT now(),
  `active` TINYINT(1) NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  INDEX `fk_passwords_users1_idx` (`users_id` ASC),
  CONSTRAINT `fk_passwords_users1`
    FOREIGN KEY (`users_id`)
    REFERENCES `users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tokens`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tokens` ;

CREATE TABLE IF NOT EXISTS `tokens` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `users_id` INT NOT NULL,
  `token` VARCHAR(255) NULL,
  `created` TIMESTAMP NULL DEFAULT now(),
  PRIMARY KEY (`id`),
  INDEX `fk_tokens_users1_idx` (`users_id` ASC),
  CONSTRAINT `fk_tokens_users1`
    FOREIGN KEY (`users_id`)
    REFERENCES `users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `users_downloaded_apps`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `users_downloaded_apps` ;

CREATE TABLE IF NOT EXISTS `users_downloaded_apps` (
  `users_id` INT NOT NULL,
  `apps_id` INT NOT NULL,
  `version` VARCHAR(25) NOT NULL,
  `timestamp` TIMESTAMP NOT NULL DEFAULT now(),
  PRIMARY KEY (`users_id`, `apps_id`, `version`, `timestamp`),
  INDEX `fk_users_has_apps_apps1_idx` (`apps_id` ASC),
  INDEX `fk_users_has_apps_users1_idx` (`users_id` ASC),
  CONSTRAINT `fk_users_has_apps_users1`
    FOREIGN KEY (`users_id`)
    REFERENCES `users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_apps_apps1`
    FOREIGN KEY (`apps_id`)
    REFERENCES `apps` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `apps_has_keywords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `apps_has_keywords` ;

CREATE TABLE IF NOT EXISTS `apps_has_keywords` (
  `apps_id` INT NOT NULL,
  `keywords_id` INT NOT NULL,
  PRIMARY KEY (`apps_id`, `keywords_id`),
  INDEX `fk_apps_has_keywords_keywords1_idx` (`keywords_id` ASC),
  INDEX `fk_apps_has_keywords_apps1_idx` (`apps_id` ASC),
  CONSTRAINT `fk_apps_has_keywords_apps1`
    FOREIGN KEY (`apps_id`)
    REFERENCES `apps` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_apps_has_keywords_keywords1`
    FOREIGN KEY (`keywords_id`)
    REFERENCES `keywords` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
